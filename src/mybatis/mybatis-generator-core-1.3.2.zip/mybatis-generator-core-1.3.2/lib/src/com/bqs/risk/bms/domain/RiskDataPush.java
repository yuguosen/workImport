package com.bqs.risk.bms.domain;

public class RiskDataPush {
    private Integer id;

    private String sftpAddress;

    private Integer sftpPort;

    private String sftpUsername;

    private String sftpPassword;

    private String sftpDirectory;

    private String partnerId;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSftpAddress() {
        return sftpAddress;
    }

    public void setSftpAddress(String sftpAddress) {
        this.sftpAddress = sftpAddress == null ? null : sftpAddress.trim();
    }

    public Integer getSftpPort() {
        return sftpPort;
    }

    public void setSftpPort(Integer sftpPort) {
        this.sftpPort = sftpPort;
    }

    public String getSftpUsername() {
        return sftpUsername;
    }

    public void setSftpUsername(String sftpUsername) {
        this.sftpUsername = sftpUsername == null ? null : sftpUsername.trim();
    }

    public String getSftpPassword() {
        return sftpPassword;
    }

    public void setSftpPassword(String sftpPassword) {
        this.sftpPassword = sftpPassword == null ? null : sftpPassword.trim();
    }

    public String getSftpDirectory() {
        return sftpDirectory;
    }

    public void setSftpDirectory(String sftpDirectory) {
        this.sftpDirectory = sftpDirectory == null ? null : sftpDirectory.trim();
    }

    public String getPartnerId() {
        return partnerId;
    }

    public void setPartnerId(String partnerId) {
        this.partnerId = partnerId == null ? null : partnerId.trim();
    }
}