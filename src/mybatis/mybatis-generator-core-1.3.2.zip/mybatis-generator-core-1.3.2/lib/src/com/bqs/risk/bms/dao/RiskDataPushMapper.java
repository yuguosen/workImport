package com.bqs.risk.bms.dao;

import com.bqs.risk.bms.domain.RiskDataPush;
import com.bqs.risk.bms.domain.RiskDataPushExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RiskDataPushMapper {
    int countByExample(RiskDataPushExample example);

    int deleteByExample(RiskDataPushExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(RiskDataPush record);

    int insertSelective(RiskDataPush record);

    List<RiskDataPush> selectByExample(RiskDataPushExample example);

    RiskDataPush selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") RiskDataPush record, @Param("example") RiskDataPushExample example);

    int updateByExample(@Param("record") RiskDataPush record, @Param("example") RiskDataPushExample example);

    int updateByPrimaryKeySelective(RiskDataPush record);

    int updateByPrimaryKey(RiskDataPush record);
}