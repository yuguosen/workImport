package com.bqs.risk.bmsdvp.dao;

import com.bqs.importdata.dao.po.RegionCodeInfo;
import com.bqs.importdata.dao.po.RegionCodeInfoExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface RegionCodeInfoMapper {
    int countByExample(RegionCodeInfoExample example);

    int deleteByExample(RegionCodeInfoExample example);

    int deleteByPrimaryKey(Long code);

    int insert(RegionCodeInfo record);

    int insertSelective(RegionCodeInfo record);

    List<RegionCodeInfo> selectByExample(RegionCodeInfoExample example);

    RegionCodeInfo selectByPrimaryKey(Long code);

    int updateByExampleSelective(@Param("record") RegionCodeInfo record, @Param("example") RegionCodeInfoExample example);

    int updateByExample(@Param("record") RegionCodeInfo record, @Param("example") RegionCodeInfoExample example);

    int updateByPrimaryKeySelective(RegionCodeInfo record);

    int updateByPrimaryKey(RegionCodeInfo record);
}