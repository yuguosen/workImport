package com.bqs.importdata.dao.po;

public class RegionCodeInfo {
    private Long code;

    private String value;

    private String province;

    private String city;

    private String county;

    private String completeAddress;

    private String longitude;

    private String latitude;

    private String phoneCode;

    private String postCode;

    private String area;

    private String population;

    private String upcode;

    private String govUrl;

    private String govAddr;

    private String historyCode;

    public Long getCode() {
        return code;
    }

    public void setCode(Long code) {
        this.code = code;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value == null ? null : value.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county == null ? null : county.trim();
    }

    public String getCompleteAddress() {
        return completeAddress;
    }

    public void setCompleteAddress(String completeAddress) {
        this.completeAddress = completeAddress == null ? null : completeAddress.trim();
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude == null ? null : longitude.trim();
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude == null ? null : latitude.trim();
    }

    public String getPhoneCode() {
        return phoneCode;
    }

    public void setPhoneCode(String phoneCode) {
        this.phoneCode = phoneCode == null ? null : phoneCode.trim();
    }

    public String getPostCode() {
        return postCode;
    }

    public void setPostCode(String postCode) {
        this.postCode = postCode == null ? null : postCode.trim();
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getPopulation() {
        return population;
    }

    public void setPopulation(String population) {
        this.population = population == null ? null : population.trim();
    }

    public String getUpcode() {
        return upcode;
    }

    public void setUpcode(String upcode) {
        this.upcode = upcode == null ? null : upcode.trim();
    }

    public String getGovUrl() {
        return govUrl;
    }

    public void setGovUrl(String govUrl) {
        this.govUrl = govUrl == null ? null : govUrl.trim();
    }

    public String getGovAddr() {
        return govAddr;
    }

    public void setGovAddr(String govAddr) {
        this.govAddr = govAddr == null ? null : govAddr.trim();
    }

    public String getHistoryCode() {
        return historyCode;
    }

    public void setHistoryCode(String historyCode) {
        this.historyCode = historyCode == null ? null : historyCode.trim();
    }
}