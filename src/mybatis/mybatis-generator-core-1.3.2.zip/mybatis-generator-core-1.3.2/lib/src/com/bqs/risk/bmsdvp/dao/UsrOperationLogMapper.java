package com.bqs.risk.bmsdvp.dao;

import com.bqs.risk.bmsdvp.domain.UsrOperationLog;
import com.bqs.risk.bmsdvp.domain.UsrOperationLogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UsrOperationLogMapper {
    int countByExample(UsrOperationLogExample example);

    int deleteByExample(UsrOperationLogExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(UsrOperationLog record);

    int insertSelective(UsrOperationLog record);

    List<UsrOperationLog> selectByExample(UsrOperationLogExample example);

    UsrOperationLog selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") UsrOperationLog record, @Param("example") UsrOperationLogExample example);

    int updateByExample(@Param("record") UsrOperationLog record, @Param("example") UsrOperationLogExample example);

    int updateByPrimaryKeySelective(UsrOperationLog record);

    int updateByPrimaryKey(UsrOperationLog record);
}