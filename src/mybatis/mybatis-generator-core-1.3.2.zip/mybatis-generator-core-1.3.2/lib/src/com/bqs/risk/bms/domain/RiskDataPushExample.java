package com.bqs.risk.bms.domain;

import java.util.ArrayList;
import java.util.List;

public class RiskDataPushExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RiskDataPushExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Integer value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Integer value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Integer value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Integer value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Integer value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Integer value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Integer> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Integer> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Integer value1, Integer value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Integer value1, Integer value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSftpAddressIsNull() {
            addCriterion("sftp_address is null");
            return (Criteria) this;
        }

        public Criteria andSftpAddressIsNotNull() {
            addCriterion("sftp_address is not null");
            return (Criteria) this;
        }

        public Criteria andSftpAddressEqualTo(String value) {
            addCriterion("sftp_address =", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressNotEqualTo(String value) {
            addCriterion("sftp_address <>", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressGreaterThan(String value) {
            addCriterion("sftp_address >", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressGreaterThanOrEqualTo(String value) {
            addCriterion("sftp_address >=", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressLessThan(String value) {
            addCriterion("sftp_address <", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressLessThanOrEqualTo(String value) {
            addCriterion("sftp_address <=", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressLike(String value) {
            addCriterion("sftp_address like", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressNotLike(String value) {
            addCriterion("sftp_address not like", value, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressIn(List<String> values) {
            addCriterion("sftp_address in", values, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressNotIn(List<String> values) {
            addCriterion("sftp_address not in", values, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressBetween(String value1, String value2) {
            addCriterion("sftp_address between", value1, value2, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpAddressNotBetween(String value1, String value2) {
            addCriterion("sftp_address not between", value1, value2, "sftpAddress");
            return (Criteria) this;
        }

        public Criteria andSftpPortIsNull() {
            addCriterion("sftp_port is null");
            return (Criteria) this;
        }

        public Criteria andSftpPortIsNotNull() {
            addCriterion("sftp_port is not null");
            return (Criteria) this;
        }

        public Criteria andSftpPortEqualTo(Integer value) {
            addCriterion("sftp_port =", value, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortNotEqualTo(Integer value) {
            addCriterion("sftp_port <>", value, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortGreaterThan(Integer value) {
            addCriterion("sftp_port >", value, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortGreaterThanOrEqualTo(Integer value) {
            addCriterion("sftp_port >=", value, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortLessThan(Integer value) {
            addCriterion("sftp_port <", value, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortLessThanOrEqualTo(Integer value) {
            addCriterion("sftp_port <=", value, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortIn(List<Integer> values) {
            addCriterion("sftp_port in", values, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortNotIn(List<Integer> values) {
            addCriterion("sftp_port not in", values, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortBetween(Integer value1, Integer value2) {
            addCriterion("sftp_port between", value1, value2, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpPortNotBetween(Integer value1, Integer value2) {
            addCriterion("sftp_port not between", value1, value2, "sftpPort");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameIsNull() {
            addCriterion("sftp_username is null");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameIsNotNull() {
            addCriterion("sftp_username is not null");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameEqualTo(String value) {
            addCriterion("sftp_username =", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameNotEqualTo(String value) {
            addCriterion("sftp_username <>", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameGreaterThan(String value) {
            addCriterion("sftp_username >", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameGreaterThanOrEqualTo(String value) {
            addCriterion("sftp_username >=", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameLessThan(String value) {
            addCriterion("sftp_username <", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameLessThanOrEqualTo(String value) {
            addCriterion("sftp_username <=", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameLike(String value) {
            addCriterion("sftp_username like", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameNotLike(String value) {
            addCriterion("sftp_username not like", value, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameIn(List<String> values) {
            addCriterion("sftp_username in", values, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameNotIn(List<String> values) {
            addCriterion("sftp_username not in", values, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameBetween(String value1, String value2) {
            addCriterion("sftp_username between", value1, value2, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpUsernameNotBetween(String value1, String value2) {
            addCriterion("sftp_username not between", value1, value2, "sftpUsername");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordIsNull() {
            addCriterion("sftp_password is null");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordIsNotNull() {
            addCriterion("sftp_password is not null");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordEqualTo(String value) {
            addCriterion("sftp_password =", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordNotEqualTo(String value) {
            addCriterion("sftp_password <>", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordGreaterThan(String value) {
            addCriterion("sftp_password >", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordGreaterThanOrEqualTo(String value) {
            addCriterion("sftp_password >=", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordLessThan(String value) {
            addCriterion("sftp_password <", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordLessThanOrEqualTo(String value) {
            addCriterion("sftp_password <=", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordLike(String value) {
            addCriterion("sftp_password like", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordNotLike(String value) {
            addCriterion("sftp_password not like", value, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordIn(List<String> values) {
            addCriterion("sftp_password in", values, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordNotIn(List<String> values) {
            addCriterion("sftp_password not in", values, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordBetween(String value1, String value2) {
            addCriterion("sftp_password between", value1, value2, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpPasswordNotBetween(String value1, String value2) {
            addCriterion("sftp_password not between", value1, value2, "sftpPassword");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryIsNull() {
            addCriterion("sftp_directory is null");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryIsNotNull() {
            addCriterion("sftp_directory is not null");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryEqualTo(String value) {
            addCriterion("sftp_directory =", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryNotEqualTo(String value) {
            addCriterion("sftp_directory <>", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryGreaterThan(String value) {
            addCriterion("sftp_directory >", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryGreaterThanOrEqualTo(String value) {
            addCriterion("sftp_directory >=", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryLessThan(String value) {
            addCriterion("sftp_directory <", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryLessThanOrEqualTo(String value) {
            addCriterion("sftp_directory <=", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryLike(String value) {
            addCriterion("sftp_directory like", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryNotLike(String value) {
            addCriterion("sftp_directory not like", value, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryIn(List<String> values) {
            addCriterion("sftp_directory in", values, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryNotIn(List<String> values) {
            addCriterion("sftp_directory not in", values, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryBetween(String value1, String value2) {
            addCriterion("sftp_directory between", value1, value2, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andSftpDirectoryNotBetween(String value1, String value2) {
            addCriterion("sftp_directory not between", value1, value2, "sftpDirectory");
            return (Criteria) this;
        }

        public Criteria andPartnerIdIsNull() {
            addCriterion("partner_id is null");
            return (Criteria) this;
        }

        public Criteria andPartnerIdIsNotNull() {
            addCriterion("partner_id is not null");
            return (Criteria) this;
        }

        public Criteria andPartnerIdEqualTo(String value) {
            addCriterion("partner_id =", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdNotEqualTo(String value) {
            addCriterion("partner_id <>", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdGreaterThan(String value) {
            addCriterion("partner_id >", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdGreaterThanOrEqualTo(String value) {
            addCriterion("partner_id >=", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdLessThan(String value) {
            addCriterion("partner_id <", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdLessThanOrEqualTo(String value) {
            addCriterion("partner_id <=", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdLike(String value) {
            addCriterion("partner_id like", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdNotLike(String value) {
            addCriterion("partner_id not like", value, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdIn(List<String> values) {
            addCriterion("partner_id in", values, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdNotIn(List<String> values) {
            addCriterion("partner_id not in", values, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdBetween(String value1, String value2) {
            addCriterion("partner_id between", value1, value2, "partnerId");
            return (Criteria) this;
        }

        public Criteria andPartnerIdNotBetween(String value1, String value2) {
            addCriterion("partner_id not between", value1, value2, "partnerId");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}