package com.bqs.risk.control.dao;

import com.bqs.risk.control.domain.UsrOperationLog;
import com.bqs.risk.control.domain.UsrOperationLogExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface UsrOperationLogMapper {
    int countByExample(UsrOperationLogExample example);

    int deleteByExample(UsrOperationLogExample example);

    int deleteByPrimaryKey(String id);

    int insert(UsrOperationLog record);

    int insertSelective(UsrOperationLog record);

    List<UsrOperationLog> selectByExample(UsrOperationLogExample example);

    UsrOperationLog selectByPrimaryKey(String id);

    int updateByExampleSelective(@Param("record") UsrOperationLog record, @Param("example") UsrOperationLogExample example);

    int updateByExample(@Param("record") UsrOperationLog record, @Param("example") UsrOperationLogExample example);

    int updateByPrimaryKeySelective(UsrOperationLog record);

    int updateByPrimaryKey(UsrOperationLog record);
}