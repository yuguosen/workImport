package com.bqs.importdata.dao.po;

import java.util.ArrayList;
import java.util.List;

public class RegionCodeInfoExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public RegionCodeInfoExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andCodeIsNull() {
            addCriterion("code is null");
            return (Criteria) this;
        }

        public Criteria andCodeIsNotNull() {
            addCriterion("code is not null");
            return (Criteria) this;
        }

        public Criteria andCodeEqualTo(Long value) {
            addCriterion("code =", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotEqualTo(Long value) {
            addCriterion("code <>", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeGreaterThan(Long value) {
            addCriterion("code >", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeGreaterThanOrEqualTo(Long value) {
            addCriterion("code >=", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLessThan(Long value) {
            addCriterion("code <", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeLessThanOrEqualTo(Long value) {
            addCriterion("code <=", value, "code");
            return (Criteria) this;
        }

        public Criteria andCodeIn(List<Long> values) {
            addCriterion("code in", values, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotIn(List<Long> values) {
            addCriterion("code not in", values, "code");
            return (Criteria) this;
        }

        public Criteria andCodeBetween(Long value1, Long value2) {
            addCriterion("code between", value1, value2, "code");
            return (Criteria) this;
        }

        public Criteria andCodeNotBetween(Long value1, Long value2) {
            addCriterion("code not between", value1, value2, "code");
            return (Criteria) this;
        }

        public Criteria andValueIsNull() {
            addCriterion("value is null");
            return (Criteria) this;
        }

        public Criteria andValueIsNotNull() {
            addCriterion("value is not null");
            return (Criteria) this;
        }

        public Criteria andValueEqualTo(String value) {
            addCriterion("value =", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueNotEqualTo(String value) {
            addCriterion("value <>", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueGreaterThan(String value) {
            addCriterion("value >", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueGreaterThanOrEqualTo(String value) {
            addCriterion("value >=", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueLessThan(String value) {
            addCriterion("value <", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueLessThanOrEqualTo(String value) {
            addCriterion("value <=", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueLike(String value) {
            addCriterion("value like", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueNotLike(String value) {
            addCriterion("value not like", value, "value");
            return (Criteria) this;
        }

        public Criteria andValueIn(List<String> values) {
            addCriterion("value in", values, "value");
            return (Criteria) this;
        }

        public Criteria andValueNotIn(List<String> values) {
            addCriterion("value not in", values, "value");
            return (Criteria) this;
        }

        public Criteria andValueBetween(String value1, String value2) {
            addCriterion("value between", value1, value2, "value");
            return (Criteria) this;
        }

        public Criteria andValueNotBetween(String value1, String value2) {
            addCriterion("value not between", value1, value2, "value");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNull() {
            addCriterion("province is null");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNotNull() {
            addCriterion("province is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceEqualTo(String value) {
            addCriterion("province =", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotEqualTo(String value) {
            addCriterion("province <>", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThan(String value) {
            addCriterion("province >", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThanOrEqualTo(String value) {
            addCriterion("province >=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThan(String value) {
            addCriterion("province <", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThanOrEqualTo(String value) {
            addCriterion("province <=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLike(String value) {
            addCriterion("province like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotLike(String value) {
            addCriterion("province not like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceIn(List<String> values) {
            addCriterion("province in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotIn(List<String> values) {
            addCriterion("province not in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceBetween(String value1, String value2) {
            addCriterion("province between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotBetween(String value1, String value2) {
            addCriterion("province not between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andCityIsNull() {
            addCriterion("city is null");
            return (Criteria) this;
        }

        public Criteria andCityIsNotNull() {
            addCriterion("city is not null");
            return (Criteria) this;
        }

        public Criteria andCityEqualTo(String value) {
            addCriterion("city =", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotEqualTo(String value) {
            addCriterion("city <>", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThan(String value) {
            addCriterion("city >", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThanOrEqualTo(String value) {
            addCriterion("city >=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThan(String value) {
            addCriterion("city <", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThanOrEqualTo(String value) {
            addCriterion("city <=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLike(String value) {
            addCriterion("city like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotLike(String value) {
            addCriterion("city not like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityIn(List<String> values) {
            addCriterion("city in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotIn(List<String> values) {
            addCriterion("city not in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityBetween(String value1, String value2) {
            addCriterion("city between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotBetween(String value1, String value2) {
            addCriterion("city not between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCountyIsNull() {
            addCriterion("county is null");
            return (Criteria) this;
        }

        public Criteria andCountyIsNotNull() {
            addCriterion("county is not null");
            return (Criteria) this;
        }

        public Criteria andCountyEqualTo(String value) {
            addCriterion("county =", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotEqualTo(String value) {
            addCriterion("county <>", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyGreaterThan(String value) {
            addCriterion("county >", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyGreaterThanOrEqualTo(String value) {
            addCriterion("county >=", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyLessThan(String value) {
            addCriterion("county <", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyLessThanOrEqualTo(String value) {
            addCriterion("county <=", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyLike(String value) {
            addCriterion("county like", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotLike(String value) {
            addCriterion("county not like", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyIn(List<String> values) {
            addCriterion("county in", values, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotIn(List<String> values) {
            addCriterion("county not in", values, "county");
            return (Criteria) this;
        }

        public Criteria andCountyBetween(String value1, String value2) {
            addCriterion("county between", value1, value2, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotBetween(String value1, String value2) {
            addCriterion("county not between", value1, value2, "county");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressIsNull() {
            addCriterion("complete_address is null");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressIsNotNull() {
            addCriterion("complete_address is not null");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressEqualTo(String value) {
            addCriterion("complete_address =", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressNotEqualTo(String value) {
            addCriterion("complete_address <>", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressGreaterThan(String value) {
            addCriterion("complete_address >", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressGreaterThanOrEqualTo(String value) {
            addCriterion("complete_address >=", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressLessThan(String value) {
            addCriterion("complete_address <", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressLessThanOrEqualTo(String value) {
            addCriterion("complete_address <=", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressLike(String value) {
            addCriterion("complete_address like", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressNotLike(String value) {
            addCriterion("complete_address not like", value, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressIn(List<String> values) {
            addCriterion("complete_address in", values, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressNotIn(List<String> values) {
            addCriterion("complete_address not in", values, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressBetween(String value1, String value2) {
            addCriterion("complete_address between", value1, value2, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andCompleteAddressNotBetween(String value1, String value2) {
            addCriterion("complete_address not between", value1, value2, "completeAddress");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNull() {
            addCriterion("longitude is null");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNotNull() {
            addCriterion("longitude is not null");
            return (Criteria) this;
        }

        public Criteria andLongitudeEqualTo(String value) {
            addCriterion("longitude =", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotEqualTo(String value) {
            addCriterion("longitude <>", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThan(String value) {
            addCriterion("longitude >", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThanOrEqualTo(String value) {
            addCriterion("longitude >=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThan(String value) {
            addCriterion("longitude <", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThanOrEqualTo(String value) {
            addCriterion("longitude <=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLike(String value) {
            addCriterion("longitude like", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotLike(String value) {
            addCriterion("longitude not like", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeIn(List<String> values) {
            addCriterion("longitude in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotIn(List<String> values) {
            addCriterion("longitude not in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeBetween(String value1, String value2) {
            addCriterion("longitude between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotBetween(String value1, String value2) {
            addCriterion("longitude not between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNull() {
            addCriterion("latitude is null");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNotNull() {
            addCriterion("latitude is not null");
            return (Criteria) this;
        }

        public Criteria andLatitudeEqualTo(String value) {
            addCriterion("latitude =", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotEqualTo(String value) {
            addCriterion("latitude <>", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThan(String value) {
            addCriterion("latitude >", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThanOrEqualTo(String value) {
            addCriterion("latitude >=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThan(String value) {
            addCriterion("latitude <", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThanOrEqualTo(String value) {
            addCriterion("latitude <=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLike(String value) {
            addCriterion("latitude like", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotLike(String value) {
            addCriterion("latitude not like", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIn(List<String> values) {
            addCriterion("latitude in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotIn(List<String> values) {
            addCriterion("latitude not in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeBetween(String value1, String value2) {
            addCriterion("latitude between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotBetween(String value1, String value2) {
            addCriterion("latitude not between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeIsNull() {
            addCriterion("phone_code is null");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeIsNotNull() {
            addCriterion("phone_code is not null");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeEqualTo(String value) {
            addCriterion("phone_code =", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeNotEqualTo(String value) {
            addCriterion("phone_code <>", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeGreaterThan(String value) {
            addCriterion("phone_code >", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeGreaterThanOrEqualTo(String value) {
            addCriterion("phone_code >=", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeLessThan(String value) {
            addCriterion("phone_code <", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeLessThanOrEqualTo(String value) {
            addCriterion("phone_code <=", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeLike(String value) {
            addCriterion("phone_code like", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeNotLike(String value) {
            addCriterion("phone_code not like", value, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeIn(List<String> values) {
            addCriterion("phone_code in", values, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeNotIn(List<String> values) {
            addCriterion("phone_code not in", values, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeBetween(String value1, String value2) {
            addCriterion("phone_code between", value1, value2, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPhoneCodeNotBetween(String value1, String value2) {
            addCriterion("phone_code not between", value1, value2, "phoneCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeIsNull() {
            addCriterion("post_code is null");
            return (Criteria) this;
        }

        public Criteria andPostCodeIsNotNull() {
            addCriterion("post_code is not null");
            return (Criteria) this;
        }

        public Criteria andPostCodeEqualTo(String value) {
            addCriterion("post_code =", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeNotEqualTo(String value) {
            addCriterion("post_code <>", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeGreaterThan(String value) {
            addCriterion("post_code >", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeGreaterThanOrEqualTo(String value) {
            addCriterion("post_code >=", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeLessThan(String value) {
            addCriterion("post_code <", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeLessThanOrEqualTo(String value) {
            addCriterion("post_code <=", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeLike(String value) {
            addCriterion("post_code like", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeNotLike(String value) {
            addCriterion("post_code not like", value, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeIn(List<String> values) {
            addCriterion("post_code in", values, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeNotIn(List<String> values) {
            addCriterion("post_code not in", values, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeBetween(String value1, String value2) {
            addCriterion("post_code between", value1, value2, "postCode");
            return (Criteria) this;
        }

        public Criteria andPostCodeNotBetween(String value1, String value2) {
            addCriterion("post_code not between", value1, value2, "postCode");
            return (Criteria) this;
        }

        public Criteria andAreaIsNull() {
            addCriterion("area is null");
            return (Criteria) this;
        }

        public Criteria andAreaIsNotNull() {
            addCriterion("area is not null");
            return (Criteria) this;
        }

        public Criteria andAreaEqualTo(String value) {
            addCriterion("area =", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotEqualTo(String value) {
            addCriterion("area <>", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaGreaterThan(String value) {
            addCriterion("area >", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaGreaterThanOrEqualTo(String value) {
            addCriterion("area >=", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLessThan(String value) {
            addCriterion("area <", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLessThanOrEqualTo(String value) {
            addCriterion("area <=", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLike(String value) {
            addCriterion("area like", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotLike(String value) {
            addCriterion("area not like", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaIn(List<String> values) {
            addCriterion("area in", values, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotIn(List<String> values) {
            addCriterion("area not in", values, "area");
            return (Criteria) this;
        }

        public Criteria andAreaBetween(String value1, String value2) {
            addCriterion("area between", value1, value2, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotBetween(String value1, String value2) {
            addCriterion("area not between", value1, value2, "area");
            return (Criteria) this;
        }

        public Criteria andPopulationIsNull() {
            addCriterion("population is null");
            return (Criteria) this;
        }

        public Criteria andPopulationIsNotNull() {
            addCriterion("population is not null");
            return (Criteria) this;
        }

        public Criteria andPopulationEqualTo(String value) {
            addCriterion("population =", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationNotEqualTo(String value) {
            addCriterion("population <>", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationGreaterThan(String value) {
            addCriterion("population >", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationGreaterThanOrEqualTo(String value) {
            addCriterion("population >=", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationLessThan(String value) {
            addCriterion("population <", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationLessThanOrEqualTo(String value) {
            addCriterion("population <=", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationLike(String value) {
            addCriterion("population like", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationNotLike(String value) {
            addCriterion("population not like", value, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationIn(List<String> values) {
            addCriterion("population in", values, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationNotIn(List<String> values) {
            addCriterion("population not in", values, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationBetween(String value1, String value2) {
            addCriterion("population between", value1, value2, "population");
            return (Criteria) this;
        }

        public Criteria andPopulationNotBetween(String value1, String value2) {
            addCriterion("population not between", value1, value2, "population");
            return (Criteria) this;
        }

        public Criteria andUpcodeIsNull() {
            addCriterion("upCode is null");
            return (Criteria) this;
        }

        public Criteria andUpcodeIsNotNull() {
            addCriterion("upCode is not null");
            return (Criteria) this;
        }

        public Criteria andUpcodeEqualTo(String value) {
            addCriterion("upCode =", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeNotEqualTo(String value) {
            addCriterion("upCode <>", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeGreaterThan(String value) {
            addCriterion("upCode >", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeGreaterThanOrEqualTo(String value) {
            addCriterion("upCode >=", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeLessThan(String value) {
            addCriterion("upCode <", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeLessThanOrEqualTo(String value) {
            addCriterion("upCode <=", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeLike(String value) {
            addCriterion("upCode like", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeNotLike(String value) {
            addCriterion("upCode not like", value, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeIn(List<String> values) {
            addCriterion("upCode in", values, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeNotIn(List<String> values) {
            addCriterion("upCode not in", values, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeBetween(String value1, String value2) {
            addCriterion("upCode between", value1, value2, "upcode");
            return (Criteria) this;
        }

        public Criteria andUpcodeNotBetween(String value1, String value2) {
            addCriterion("upCode not between", value1, value2, "upcode");
            return (Criteria) this;
        }

        public Criteria andGovUrlIsNull() {
            addCriterion("gov_url is null");
            return (Criteria) this;
        }

        public Criteria andGovUrlIsNotNull() {
            addCriterion("gov_url is not null");
            return (Criteria) this;
        }

        public Criteria andGovUrlEqualTo(String value) {
            addCriterion("gov_url =", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlNotEqualTo(String value) {
            addCriterion("gov_url <>", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlGreaterThan(String value) {
            addCriterion("gov_url >", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlGreaterThanOrEqualTo(String value) {
            addCriterion("gov_url >=", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlLessThan(String value) {
            addCriterion("gov_url <", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlLessThanOrEqualTo(String value) {
            addCriterion("gov_url <=", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlLike(String value) {
            addCriterion("gov_url like", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlNotLike(String value) {
            addCriterion("gov_url not like", value, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlIn(List<String> values) {
            addCriterion("gov_url in", values, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlNotIn(List<String> values) {
            addCriterion("gov_url not in", values, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlBetween(String value1, String value2) {
            addCriterion("gov_url between", value1, value2, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovUrlNotBetween(String value1, String value2) {
            addCriterion("gov_url not between", value1, value2, "govUrl");
            return (Criteria) this;
        }

        public Criteria andGovAddrIsNull() {
            addCriterion("gov_addr is null");
            return (Criteria) this;
        }

        public Criteria andGovAddrIsNotNull() {
            addCriterion("gov_addr is not null");
            return (Criteria) this;
        }

        public Criteria andGovAddrEqualTo(String value) {
            addCriterion("gov_addr =", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrNotEqualTo(String value) {
            addCriterion("gov_addr <>", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrGreaterThan(String value) {
            addCriterion("gov_addr >", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrGreaterThanOrEqualTo(String value) {
            addCriterion("gov_addr >=", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrLessThan(String value) {
            addCriterion("gov_addr <", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrLessThanOrEqualTo(String value) {
            addCriterion("gov_addr <=", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrLike(String value) {
            addCriterion("gov_addr like", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrNotLike(String value) {
            addCriterion("gov_addr not like", value, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrIn(List<String> values) {
            addCriterion("gov_addr in", values, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrNotIn(List<String> values) {
            addCriterion("gov_addr not in", values, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrBetween(String value1, String value2) {
            addCriterion("gov_addr between", value1, value2, "govAddr");
            return (Criteria) this;
        }

        public Criteria andGovAddrNotBetween(String value1, String value2) {
            addCriterion("gov_addr not between", value1, value2, "govAddr");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeIsNull() {
            addCriterion("history_code is null");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeIsNotNull() {
            addCriterion("history_code is not null");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeEqualTo(String value) {
            addCriterion("history_code =", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeNotEqualTo(String value) {
            addCriterion("history_code <>", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeGreaterThan(String value) {
            addCriterion("history_code >", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeGreaterThanOrEqualTo(String value) {
            addCriterion("history_code >=", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeLessThan(String value) {
            addCriterion("history_code <", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeLessThanOrEqualTo(String value) {
            addCriterion("history_code <=", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeLike(String value) {
            addCriterion("history_code like", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeNotLike(String value) {
            addCriterion("history_code not like", value, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeIn(List<String> values) {
            addCriterion("history_code in", values, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeNotIn(List<String> values) {
            addCriterion("history_code not in", values, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeBetween(String value1, String value2) {
            addCriterion("history_code between", value1, value2, "historyCode");
            return (Criteria) this;
        }

        public Criteria andHistoryCodeNotBetween(String value1, String value2) {
            addCriterion("history_code not between", value1, value2, "historyCode");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}