package com.test.all.importdata.dao.mapper;

import com.test.all.importdata.dao.po.Ip;
import com.test.all.importdata.dao.po.IpExample;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface IpMapper {
    int countByExample(IpExample example);

    int deleteByExample(IpExample example);

    int insert(Ip record);

    int insertSelective(Ip record);

    List<Ip> selectByExample(IpExample example);

    int updateByExampleSelective(@Param("record") Ip record, @Param("example") IpExample example);

    int updateByExample(@Param("record") Ip record, @Param("example") IpExample example);
}