package com.test.all.importdata.dao.po;

import java.util.ArrayList;
import java.util.List;

public class IpExample {
    protected String orderByClause;

    protected boolean distinct;

    protected List<Criteria> oredCriteria;

    public IpExample() {
        oredCriteria = new ArrayList<Criteria>();
    }

    public void setOrderByClause(String orderByClause) {
        this.orderByClause = orderByClause;
    }

    public String getOrderByClause() {
        return orderByClause;
    }

    public void setDistinct(boolean distinct) {
        this.distinct = distinct;
    }

    public boolean isDistinct() {
        return distinct;
    }

    public List<Criteria> getOredCriteria() {
        return oredCriteria;
    }

    public void or(Criteria criteria) {
        oredCriteria.add(criteria);
    }

    public Criteria or() {
        Criteria criteria = createCriteriaInternal();
        oredCriteria.add(criteria);
        return criteria;
    }

    public Criteria createCriteria() {
        Criteria criteria = createCriteriaInternal();
        if (oredCriteria.size() == 0) {
            oredCriteria.add(criteria);
        }
        return criteria;
    }

    protected Criteria createCriteriaInternal() {
        Criteria criteria = new Criteria();
        return criteria;
    }

    public void clear() {
        oredCriteria.clear();
        orderByClause = null;
        distinct = false;
    }

    protected abstract static class GeneratedCriteria {
        protected List<Criterion> criteria;

        protected GeneratedCriteria() {
            super();
            criteria = new ArrayList<Criterion>();
        }

        public boolean isValid() {
            return criteria.size() > 0;
        }

        public List<Criterion> getAllCriteria() {
            return criteria;
        }

        public List<Criterion> getCriteria() {
            return criteria;
        }

        protected void addCriterion(String condition) {
            if (condition == null) {
                throw new RuntimeException("Value for condition cannot be null");
            }
            criteria.add(new Criterion(condition));
        }

        protected void addCriterion(String condition, Object value, String property) {
            if (value == null) {
                throw new RuntimeException("Value for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value));
        }

        protected void addCriterion(String condition, Object value1, Object value2, String property) {
            if (value1 == null || value2 == null) {
                throw new RuntimeException("Between values for " + property + " cannot be null");
            }
            criteria.add(new Criterion(condition, value1, value2));
        }

        public Criteria andIdIsNull() {
            addCriterion("id is null");
            return (Criteria) this;
        }

        public Criteria andIdIsNotNull() {
            addCriterion("id is not null");
            return (Criteria) this;
        }

        public Criteria andIdEqualTo(Long value) {
            addCriterion("id =", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotEqualTo(Long value) {
            addCriterion("id <>", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThan(Long value) {
            addCriterion("id >", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdGreaterThanOrEqualTo(Long value) {
            addCriterion("id >=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThan(Long value) {
            addCriterion("id <", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdLessThanOrEqualTo(Long value) {
            addCriterion("id <=", value, "id");
            return (Criteria) this;
        }

        public Criteria andIdIn(List<Long> values) {
            addCriterion("id in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotIn(List<Long> values) {
            addCriterion("id not in", values, "id");
            return (Criteria) this;
        }

        public Criteria andIdBetween(Long value1, Long value2) {
            addCriterion("id between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andIdNotBetween(Long value1, Long value2) {
            addCriterion("id not between", value1, value2, "id");
            return (Criteria) this;
        }

        public Criteria andSourceIsNull() {
            addCriterion("source is null");
            return (Criteria) this;
        }

        public Criteria andSourceIsNotNull() {
            addCriterion("source is not null");
            return (Criteria) this;
        }

        public Criteria andSourceEqualTo(String value) {
            addCriterion("source =", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotEqualTo(String value) {
            addCriterion("source <>", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThan(String value) {
            addCriterion("source >", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceGreaterThanOrEqualTo(String value) {
            addCriterion("source >=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThan(String value) {
            addCriterion("source <", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLessThanOrEqualTo(String value) {
            addCriterion("source <=", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceLike(String value) {
            addCriterion("source like", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotLike(String value) {
            addCriterion("source not like", value, "source");
            return (Criteria) this;
        }

        public Criteria andSourceIn(List<String> values) {
            addCriterion("source in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotIn(List<String> values) {
            addCriterion("source not in", values, "source");
            return (Criteria) this;
        }

        public Criteria andSourceBetween(String value1, String value2) {
            addCriterion("source between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andSourceNotBetween(String value1, String value2) {
            addCriterion("source not between", value1, value2, "source");
            return (Criteria) this;
        }

        public Criteria andIpstartIsNull() {
            addCriterion("ipstart is null");
            return (Criteria) this;
        }

        public Criteria andIpstartIsNotNull() {
            addCriterion("ipstart is not null");
            return (Criteria) this;
        }

        public Criteria andIpstartEqualTo(String value) {
            addCriterion("ipstart =", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartNotEqualTo(String value) {
            addCriterion("ipstart <>", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartGreaterThan(String value) {
            addCriterion("ipstart >", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartGreaterThanOrEqualTo(String value) {
            addCriterion("ipstart >=", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartLessThan(String value) {
            addCriterion("ipstart <", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartLessThanOrEqualTo(String value) {
            addCriterion("ipstart <=", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartLike(String value) {
            addCriterion("ipstart like", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartNotLike(String value) {
            addCriterion("ipstart not like", value, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartIn(List<String> values) {
            addCriterion("ipstart in", values, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartNotIn(List<String> values) {
            addCriterion("ipstart not in", values, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartBetween(String value1, String value2) {
            addCriterion("ipstart between", value1, value2, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartNotBetween(String value1, String value2) {
            addCriterion("ipstart not between", value1, value2, "ipstart");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalIsNull() {
            addCriterion("ipstartdigital is null");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalIsNotNull() {
            addCriterion("ipstartdigital is not null");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalEqualTo(Long value) {
            addCriterion("ipstartdigital =", value, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalNotEqualTo(Long value) {
            addCriterion("ipstartdigital <>", value, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalGreaterThan(Long value) {
            addCriterion("ipstartdigital >", value, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalGreaterThanOrEqualTo(Long value) {
            addCriterion("ipstartdigital >=", value, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalLessThan(Long value) {
            addCriterion("ipstartdigital <", value, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalLessThanOrEqualTo(Long value) {
            addCriterion("ipstartdigital <=", value, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalIn(List<Long> values) {
            addCriterion("ipstartdigital in", values, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalNotIn(List<Long> values) {
            addCriterion("ipstartdigital not in", values, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalBetween(Long value1, Long value2) {
            addCriterion("ipstartdigital between", value1, value2, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpstartdigitalNotBetween(Long value1, Long value2) {
            addCriterion("ipstartdigital not between", value1, value2, "ipstartdigital");
            return (Criteria) this;
        }

        public Criteria andIpendIsNull() {
            addCriterion("ipend is null");
            return (Criteria) this;
        }

        public Criteria andIpendIsNotNull() {
            addCriterion("ipend is not null");
            return (Criteria) this;
        }

        public Criteria andIpendEqualTo(String value) {
            addCriterion("ipend =", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendNotEqualTo(String value) {
            addCriterion("ipend <>", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendGreaterThan(String value) {
            addCriterion("ipend >", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendGreaterThanOrEqualTo(String value) {
            addCriterion("ipend >=", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendLessThan(String value) {
            addCriterion("ipend <", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendLessThanOrEqualTo(String value) {
            addCriterion("ipend <=", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendLike(String value) {
            addCriterion("ipend like", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendNotLike(String value) {
            addCriterion("ipend not like", value, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendIn(List<String> values) {
            addCriterion("ipend in", values, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendNotIn(List<String> values) {
            addCriterion("ipend not in", values, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendBetween(String value1, String value2) {
            addCriterion("ipend between", value1, value2, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpendNotBetween(String value1, String value2) {
            addCriterion("ipend not between", value1, value2, "ipend");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalIsNull() {
            addCriterion("ipenddigital is null");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalIsNotNull() {
            addCriterion("ipenddigital is not null");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalEqualTo(Long value) {
            addCriterion("ipenddigital =", value, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalNotEqualTo(Long value) {
            addCriterion("ipenddigital <>", value, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalGreaterThan(Long value) {
            addCriterion("ipenddigital >", value, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalGreaterThanOrEqualTo(Long value) {
            addCriterion("ipenddigital >=", value, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalLessThan(Long value) {
            addCriterion("ipenddigital <", value, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalLessThanOrEqualTo(Long value) {
            addCriterion("ipenddigital <=", value, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalIn(List<Long> values) {
            addCriterion("ipenddigital in", values, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalNotIn(List<Long> values) {
            addCriterion("ipenddigital not in", values, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalBetween(Long value1, Long value2) {
            addCriterion("ipenddigital between", value1, value2, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andIpenddigitalNotBetween(Long value1, Long value2) {
            addCriterion("ipenddigital not between", value1, value2, "ipenddigital");
            return (Criteria) this;
        }

        public Criteria andAreaIsNull() {
            addCriterion("area is null");
            return (Criteria) this;
        }

        public Criteria andAreaIsNotNull() {
            addCriterion("area is not null");
            return (Criteria) this;
        }

        public Criteria andAreaEqualTo(String value) {
            addCriterion("area =", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotEqualTo(String value) {
            addCriterion("area <>", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaGreaterThan(String value) {
            addCriterion("area >", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaGreaterThanOrEqualTo(String value) {
            addCriterion("area >=", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLessThan(String value) {
            addCriterion("area <", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLessThanOrEqualTo(String value) {
            addCriterion("area <=", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaLike(String value) {
            addCriterion("area like", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotLike(String value) {
            addCriterion("area not like", value, "area");
            return (Criteria) this;
        }

        public Criteria andAreaIn(List<String> values) {
            addCriterion("area in", values, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotIn(List<String> values) {
            addCriterion("area not in", values, "area");
            return (Criteria) this;
        }

        public Criteria andAreaBetween(String value1, String value2) {
            addCriterion("area between", value1, value2, "area");
            return (Criteria) this;
        }

        public Criteria andAreaNotBetween(String value1, String value2) {
            addCriterion("area not between", value1, value2, "area");
            return (Criteria) this;
        }

        public Criteria andAreaIdIsNull() {
            addCriterion("area_id is null");
            return (Criteria) this;
        }

        public Criteria andAreaIdIsNotNull() {
            addCriterion("area_id is not null");
            return (Criteria) this;
        }

        public Criteria andAreaIdEqualTo(String value) {
            addCriterion("area_id =", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdNotEqualTo(String value) {
            addCriterion("area_id <>", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdGreaterThan(String value) {
            addCriterion("area_id >", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdGreaterThanOrEqualTo(String value) {
            addCriterion("area_id >=", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdLessThan(String value) {
            addCriterion("area_id <", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdLessThanOrEqualTo(String value) {
            addCriterion("area_id <=", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdLike(String value) {
            addCriterion("area_id like", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdNotLike(String value) {
            addCriterion("area_id not like", value, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdIn(List<String> values) {
            addCriterion("area_id in", values, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdNotIn(List<String> values) {
            addCriterion("area_id not in", values, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdBetween(String value1, String value2) {
            addCriterion("area_id between", value1, value2, "areaId");
            return (Criteria) this;
        }

        public Criteria andAreaIdNotBetween(String value1, String value2) {
            addCriterion("area_id not between", value1, value2, "areaId");
            return (Criteria) this;
        }

        public Criteria andCityIsNull() {
            addCriterion("city is null");
            return (Criteria) this;
        }

        public Criteria andCityIsNotNull() {
            addCriterion("city is not null");
            return (Criteria) this;
        }

        public Criteria andCityEqualTo(String value) {
            addCriterion("city =", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotEqualTo(String value) {
            addCriterion("city <>", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThan(String value) {
            addCriterion("city >", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityGreaterThanOrEqualTo(String value) {
            addCriterion("city >=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThan(String value) {
            addCriterion("city <", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLessThanOrEqualTo(String value) {
            addCriterion("city <=", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityLike(String value) {
            addCriterion("city like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotLike(String value) {
            addCriterion("city not like", value, "city");
            return (Criteria) this;
        }

        public Criteria andCityIn(List<String> values) {
            addCriterion("city in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotIn(List<String> values) {
            addCriterion("city not in", values, "city");
            return (Criteria) this;
        }

        public Criteria andCityBetween(String value1, String value2) {
            addCriterion("city between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityNotBetween(String value1, String value2) {
            addCriterion("city not between", value1, value2, "city");
            return (Criteria) this;
        }

        public Criteria andCityIdIsNull() {
            addCriterion("city_id is null");
            return (Criteria) this;
        }

        public Criteria andCityIdIsNotNull() {
            addCriterion("city_id is not null");
            return (Criteria) this;
        }

        public Criteria andCityIdEqualTo(String value) {
            addCriterion("city_id =", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdNotEqualTo(String value) {
            addCriterion("city_id <>", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdGreaterThan(String value) {
            addCriterion("city_id >", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdGreaterThanOrEqualTo(String value) {
            addCriterion("city_id >=", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdLessThan(String value) {
            addCriterion("city_id <", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdLessThanOrEqualTo(String value) {
            addCriterion("city_id <=", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdLike(String value) {
            addCriterion("city_id like", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdNotLike(String value) {
            addCriterion("city_id not like", value, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdIn(List<String> values) {
            addCriterion("city_id in", values, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdNotIn(List<String> values) {
            addCriterion("city_id not in", values, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdBetween(String value1, String value2) {
            addCriterion("city_id between", value1, value2, "cityId");
            return (Criteria) this;
        }

        public Criteria andCityIdNotBetween(String value1, String value2) {
            addCriterion("city_id not between", value1, value2, "cityId");
            return (Criteria) this;
        }

        public Criteria andCountryIsNull() {
            addCriterion("country is null");
            return (Criteria) this;
        }

        public Criteria andCountryIsNotNull() {
            addCriterion("country is not null");
            return (Criteria) this;
        }

        public Criteria andCountryEqualTo(String value) {
            addCriterion("country =", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotEqualTo(String value) {
            addCriterion("country <>", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryGreaterThan(String value) {
            addCriterion("country >", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryGreaterThanOrEqualTo(String value) {
            addCriterion("country >=", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLessThan(String value) {
            addCriterion("country <", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLessThanOrEqualTo(String value) {
            addCriterion("country <=", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryLike(String value) {
            addCriterion("country like", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotLike(String value) {
            addCriterion("country not like", value, "country");
            return (Criteria) this;
        }

        public Criteria andCountryIn(List<String> values) {
            addCriterion("country in", values, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotIn(List<String> values) {
            addCriterion("country not in", values, "country");
            return (Criteria) this;
        }

        public Criteria andCountryBetween(String value1, String value2) {
            addCriterion("country between", value1, value2, "country");
            return (Criteria) this;
        }

        public Criteria andCountryNotBetween(String value1, String value2) {
            addCriterion("country not between", value1, value2, "country");
            return (Criteria) this;
        }

        public Criteria andCountryIdIsNull() {
            addCriterion("country_id is null");
            return (Criteria) this;
        }

        public Criteria andCountryIdIsNotNull() {
            addCriterion("country_id is not null");
            return (Criteria) this;
        }

        public Criteria andCountryIdEqualTo(String value) {
            addCriterion("country_id =", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotEqualTo(String value) {
            addCriterion("country_id <>", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdGreaterThan(String value) {
            addCriterion("country_id >", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdGreaterThanOrEqualTo(String value) {
            addCriterion("country_id >=", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdLessThan(String value) {
            addCriterion("country_id <", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdLessThanOrEqualTo(String value) {
            addCriterion("country_id <=", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdLike(String value) {
            addCriterion("country_id like", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotLike(String value) {
            addCriterion("country_id not like", value, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdIn(List<String> values) {
            addCriterion("country_id in", values, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotIn(List<String> values) {
            addCriterion("country_id not in", values, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdBetween(String value1, String value2) {
            addCriterion("country_id between", value1, value2, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountryIdNotBetween(String value1, String value2) {
            addCriterion("country_id not between", value1, value2, "countryId");
            return (Criteria) this;
        }

        public Criteria andCountyIsNull() {
            addCriterion("county is null");
            return (Criteria) this;
        }

        public Criteria andCountyIsNotNull() {
            addCriterion("county is not null");
            return (Criteria) this;
        }

        public Criteria andCountyEqualTo(String value) {
            addCriterion("county =", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotEqualTo(String value) {
            addCriterion("county <>", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyGreaterThan(String value) {
            addCriterion("county >", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyGreaterThanOrEqualTo(String value) {
            addCriterion("county >=", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyLessThan(String value) {
            addCriterion("county <", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyLessThanOrEqualTo(String value) {
            addCriterion("county <=", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyLike(String value) {
            addCriterion("county like", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotLike(String value) {
            addCriterion("county not like", value, "county");
            return (Criteria) this;
        }

        public Criteria andCountyIn(List<String> values) {
            addCriterion("county in", values, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotIn(List<String> values) {
            addCriterion("county not in", values, "county");
            return (Criteria) this;
        }

        public Criteria andCountyBetween(String value1, String value2) {
            addCriterion("county between", value1, value2, "county");
            return (Criteria) this;
        }

        public Criteria andCountyNotBetween(String value1, String value2) {
            addCriterion("county not between", value1, value2, "county");
            return (Criteria) this;
        }

        public Criteria andCountyIdIsNull() {
            addCriterion("county_id is null");
            return (Criteria) this;
        }

        public Criteria andCountyIdIsNotNull() {
            addCriterion("county_id is not null");
            return (Criteria) this;
        }

        public Criteria andCountyIdEqualTo(String value) {
            addCriterion("county_id =", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdNotEqualTo(String value) {
            addCriterion("county_id <>", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdGreaterThan(String value) {
            addCriterion("county_id >", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdGreaterThanOrEqualTo(String value) {
            addCriterion("county_id >=", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdLessThan(String value) {
            addCriterion("county_id <", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdLessThanOrEqualTo(String value) {
            addCriterion("county_id <=", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdLike(String value) {
            addCriterion("county_id like", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdNotLike(String value) {
            addCriterion("county_id not like", value, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdIn(List<String> values) {
            addCriterion("county_id in", values, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdNotIn(List<String> values) {
            addCriterion("county_id not in", values, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdBetween(String value1, String value2) {
            addCriterion("county_id between", value1, value2, "countyId");
            return (Criteria) this;
        }

        public Criteria andCountyIdNotBetween(String value1, String value2) {
            addCriterion("county_id not between", value1, value2, "countyId");
            return (Criteria) this;
        }

        public Criteria andIspIsNull() {
            addCriterion("isp is null");
            return (Criteria) this;
        }

        public Criteria andIspIsNotNull() {
            addCriterion("isp is not null");
            return (Criteria) this;
        }

        public Criteria andIspEqualTo(String value) {
            addCriterion("isp =", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspNotEqualTo(String value) {
            addCriterion("isp <>", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspGreaterThan(String value) {
            addCriterion("isp >", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspGreaterThanOrEqualTo(String value) {
            addCriterion("isp >=", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspLessThan(String value) {
            addCriterion("isp <", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspLessThanOrEqualTo(String value) {
            addCriterion("isp <=", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspLike(String value) {
            addCriterion("isp like", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspNotLike(String value) {
            addCriterion("isp not like", value, "isp");
            return (Criteria) this;
        }

        public Criteria andIspIn(List<String> values) {
            addCriterion("isp in", values, "isp");
            return (Criteria) this;
        }

        public Criteria andIspNotIn(List<String> values) {
            addCriterion("isp not in", values, "isp");
            return (Criteria) this;
        }

        public Criteria andIspBetween(String value1, String value2) {
            addCriterion("isp between", value1, value2, "isp");
            return (Criteria) this;
        }

        public Criteria andIspNotBetween(String value1, String value2) {
            addCriterion("isp not between", value1, value2, "isp");
            return (Criteria) this;
        }

        public Criteria andIspIdIsNull() {
            addCriterion("isp_id is null");
            return (Criteria) this;
        }

        public Criteria andIspIdIsNotNull() {
            addCriterion("isp_id is not null");
            return (Criteria) this;
        }

        public Criteria andIspIdEqualTo(String value) {
            addCriterion("isp_id =", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdNotEqualTo(String value) {
            addCriterion("isp_id <>", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdGreaterThan(String value) {
            addCriterion("isp_id >", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdGreaterThanOrEqualTo(String value) {
            addCriterion("isp_id >=", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdLessThan(String value) {
            addCriterion("isp_id <", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdLessThanOrEqualTo(String value) {
            addCriterion("isp_id <=", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdLike(String value) {
            addCriterion("isp_id like", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdNotLike(String value) {
            addCriterion("isp_id not like", value, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdIn(List<String> values) {
            addCriterion("isp_id in", values, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdNotIn(List<String> values) {
            addCriterion("isp_id not in", values, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdBetween(String value1, String value2) {
            addCriterion("isp_id between", value1, value2, "ispId");
            return (Criteria) this;
        }

        public Criteria andIspIdNotBetween(String value1, String value2) {
            addCriterion("isp_id not between", value1, value2, "ispId");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNull() {
            addCriterion("province is null");
            return (Criteria) this;
        }

        public Criteria andProvinceIsNotNull() {
            addCriterion("province is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceEqualTo(String value) {
            addCriterion("province =", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotEqualTo(String value) {
            addCriterion("province <>", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThan(String value) {
            addCriterion("province >", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceGreaterThanOrEqualTo(String value) {
            addCriterion("province >=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThan(String value) {
            addCriterion("province <", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLessThanOrEqualTo(String value) {
            addCriterion("province <=", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceLike(String value) {
            addCriterion("province like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotLike(String value) {
            addCriterion("province not like", value, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceIn(List<String> values) {
            addCriterion("province in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotIn(List<String> values) {
            addCriterion("province not in", values, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceBetween(String value1, String value2) {
            addCriterion("province between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceNotBetween(String value1, String value2) {
            addCriterion("province not between", value1, value2, "province");
            return (Criteria) this;
        }

        public Criteria andProvinceIdIsNull() {
            addCriterion("province_id is null");
            return (Criteria) this;
        }

        public Criteria andProvinceIdIsNotNull() {
            addCriterion("province_id is not null");
            return (Criteria) this;
        }

        public Criteria andProvinceIdEqualTo(String value) {
            addCriterion("province_id =", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdNotEqualTo(String value) {
            addCriterion("province_id <>", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdGreaterThan(String value) {
            addCriterion("province_id >", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdGreaterThanOrEqualTo(String value) {
            addCriterion("province_id >=", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdLessThan(String value) {
            addCriterion("province_id <", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdLessThanOrEqualTo(String value) {
            addCriterion("province_id <=", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdLike(String value) {
            addCriterion("province_id like", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdNotLike(String value) {
            addCriterion("province_id not like", value, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdIn(List<String> values) {
            addCriterion("province_id in", values, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdNotIn(List<String> values) {
            addCriterion("province_id not in", values, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdBetween(String value1, String value2) {
            addCriterion("province_id between", value1, value2, "provinceId");
            return (Criteria) this;
        }

        public Criteria andProvinceIdNotBetween(String value1, String value2) {
            addCriterion("province_id not between", value1, value2, "provinceId");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNull() {
            addCriterion("longitude is null");
            return (Criteria) this;
        }

        public Criteria andLongitudeIsNotNull() {
            addCriterion("longitude is not null");
            return (Criteria) this;
        }

        public Criteria andLongitudeEqualTo(String value) {
            addCriterion("longitude =", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotEqualTo(String value) {
            addCriterion("longitude <>", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThan(String value) {
            addCriterion("longitude >", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeGreaterThanOrEqualTo(String value) {
            addCriterion("longitude >=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThan(String value) {
            addCriterion("longitude <", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLessThanOrEqualTo(String value) {
            addCriterion("longitude <=", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeLike(String value) {
            addCriterion("longitude like", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotLike(String value) {
            addCriterion("longitude not like", value, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeIn(List<String> values) {
            addCriterion("longitude in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotIn(List<String> values) {
            addCriterion("longitude not in", values, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeBetween(String value1, String value2) {
            addCriterion("longitude between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLongitudeNotBetween(String value1, String value2) {
            addCriterion("longitude not between", value1, value2, "longitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNull() {
            addCriterion("latitude is null");
            return (Criteria) this;
        }

        public Criteria andLatitudeIsNotNull() {
            addCriterion("latitude is not null");
            return (Criteria) this;
        }

        public Criteria andLatitudeEqualTo(String value) {
            addCriterion("latitude =", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotEqualTo(String value) {
            addCriterion("latitude <>", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThan(String value) {
            addCriterion("latitude >", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeGreaterThanOrEqualTo(String value) {
            addCriterion("latitude >=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThan(String value) {
            addCriterion("latitude <", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLessThanOrEqualTo(String value) {
            addCriterion("latitude <=", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeLike(String value) {
            addCriterion("latitude like", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotLike(String value) {
            addCriterion("latitude not like", value, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeIn(List<String> values) {
            addCriterion("latitude in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotIn(List<String> values) {
            addCriterion("latitude not in", values, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeBetween(String value1, String value2) {
            addCriterion("latitude between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andLatitudeNotBetween(String value1, String value2) {
            addCriterion("latitude not between", value1, value2, "latitude");
            return (Criteria) this;
        }

        public Criteria andAddressTypeIsNull() {
            addCriterion("address_type is null");
            return (Criteria) this;
        }

        public Criteria andAddressTypeIsNotNull() {
            addCriterion("address_type is not null");
            return (Criteria) this;
        }

        public Criteria andAddressTypeEqualTo(String value) {
            addCriterion("address_type =", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeNotEqualTo(String value) {
            addCriterion("address_type <>", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeGreaterThan(String value) {
            addCriterion("address_type >", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeGreaterThanOrEqualTo(String value) {
            addCriterion("address_type >=", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeLessThan(String value) {
            addCriterion("address_type <", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeLessThanOrEqualTo(String value) {
            addCriterion("address_type <=", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeLike(String value) {
            addCriterion("address_type like", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeNotLike(String value) {
            addCriterion("address_type not like", value, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeIn(List<String> values) {
            addCriterion("address_type in", values, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeNotIn(List<String> values) {
            addCriterion("address_type not in", values, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeBetween(String value1, String value2) {
            addCriterion("address_type between", value1, value2, "addressType");
            return (Criteria) this;
        }

        public Criteria andAddressTypeNotBetween(String value1, String value2) {
            addCriterion("address_type not between", value1, value2, "addressType");
            return (Criteria) this;
        }

        public Criteria andTypeIsNull() {
            addCriterion("type is null");
            return (Criteria) this;
        }

        public Criteria andTypeIsNotNull() {
            addCriterion("type is not null");
            return (Criteria) this;
        }

        public Criteria andTypeEqualTo(String value) {
            addCriterion("type =", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotEqualTo(String value) {
            addCriterion("type <>", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThan(String value) {
            addCriterion("type >", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeGreaterThanOrEqualTo(String value) {
            addCriterion("type >=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThan(String value) {
            addCriterion("type <", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLessThanOrEqualTo(String value) {
            addCriterion("type <=", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeLike(String value) {
            addCriterion("type like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotLike(String value) {
            addCriterion("type not like", value, "type");
            return (Criteria) this;
        }

        public Criteria andTypeIn(List<String> values) {
            addCriterion("type in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotIn(List<String> values) {
            addCriterion("type not in", values, "type");
            return (Criteria) this;
        }

        public Criteria andTypeBetween(String value1, String value2) {
            addCriterion("type between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andTypeNotBetween(String value1, String value2) {
            addCriterion("type not between", value1, value2, "type");
            return (Criteria) this;
        }

        public Criteria andStateIsNull() {
            addCriterion("state is null");
            return (Criteria) this;
        }

        public Criteria andStateIsNotNull() {
            addCriterion("state is not null");
            return (Criteria) this;
        }

        public Criteria andStateEqualTo(Integer value) {
            addCriterion("state =", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotEqualTo(Integer value) {
            addCriterion("state <>", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateGreaterThan(Integer value) {
            addCriterion("state >", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateGreaterThanOrEqualTo(Integer value) {
            addCriterion("state >=", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLessThan(Integer value) {
            addCriterion("state <", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateLessThanOrEqualTo(Integer value) {
            addCriterion("state <=", value, "state");
            return (Criteria) this;
        }

        public Criteria andStateIn(List<Integer> values) {
            addCriterion("state in", values, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotIn(List<Integer> values) {
            addCriterion("state not in", values, "state");
            return (Criteria) this;
        }

        public Criteria andStateBetween(Integer value1, Integer value2) {
            addCriterion("state between", value1, value2, "state");
            return (Criteria) this;
        }

        public Criteria andStateNotBetween(Integer value1, Integer value2) {
            addCriterion("state not between", value1, value2, "state");
            return (Criteria) this;
        }

        public Criteria andIpownerIsNull() {
            addCriterion("ipowner is null");
            return (Criteria) this;
        }

        public Criteria andIpownerIsNotNull() {
            addCriterion("ipowner is not null");
            return (Criteria) this;
        }

        public Criteria andIpownerEqualTo(String value) {
            addCriterion("ipowner =", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerNotEqualTo(String value) {
            addCriterion("ipowner <>", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerGreaterThan(String value) {
            addCriterion("ipowner >", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerGreaterThanOrEqualTo(String value) {
            addCriterion("ipowner >=", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerLessThan(String value) {
            addCriterion("ipowner <", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerLessThanOrEqualTo(String value) {
            addCriterion("ipowner <=", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerLike(String value) {
            addCriterion("ipowner like", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerNotLike(String value) {
            addCriterion("ipowner not like", value, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerIn(List<String> values) {
            addCriterion("ipowner in", values, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerNotIn(List<String> values) {
            addCriterion("ipowner not in", values, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerBetween(String value1, String value2) {
            addCriterion("ipowner between", value1, value2, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIpownerNotBetween(String value1, String value2) {
            addCriterion("ipowner not between", value1, value2, "ipowner");
            return (Criteria) this;
        }

        public Criteria andIptimezoneIsNull() {
            addCriterion("iptimezone is null");
            return (Criteria) this;
        }

        public Criteria andIptimezoneIsNotNull() {
            addCriterion("iptimezone is not null");
            return (Criteria) this;
        }

        public Criteria andIptimezoneEqualTo(String value) {
            addCriterion("iptimezone =", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneNotEqualTo(String value) {
            addCriterion("iptimezone <>", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneGreaterThan(String value) {
            addCriterion("iptimezone >", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneGreaterThanOrEqualTo(String value) {
            addCriterion("iptimezone >=", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneLessThan(String value) {
            addCriterion("iptimezone <", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneLessThanOrEqualTo(String value) {
            addCriterion("iptimezone <=", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneLike(String value) {
            addCriterion("iptimezone like", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneNotLike(String value) {
            addCriterion("iptimezone not like", value, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneIn(List<String> values) {
            addCriterion("iptimezone in", values, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneNotIn(List<String> values) {
            addCriterion("iptimezone not in", values, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneBetween(String value1, String value2) {
            addCriterion("iptimezone between", value1, value2, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andIptimezoneNotBetween(String value1, String value2) {
            addCriterion("iptimezone not between", value1, value2, "iptimezone");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeIsNull() {
            addCriterion("globalcode is null");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeIsNotNull() {
            addCriterion("globalcode is not null");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeEqualTo(String value) {
            addCriterion("globalcode =", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeNotEqualTo(String value) {
            addCriterion("globalcode <>", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeGreaterThan(String value) {
            addCriterion("globalcode >", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeGreaterThanOrEqualTo(String value) {
            addCriterion("globalcode >=", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeLessThan(String value) {
            addCriterion("globalcode <", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeLessThanOrEqualTo(String value) {
            addCriterion("globalcode <=", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeLike(String value) {
            addCriterion("globalcode like", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeNotLike(String value) {
            addCriterion("globalcode not like", value, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeIn(List<String> values) {
            addCriterion("globalcode in", values, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeNotIn(List<String> values) {
            addCriterion("globalcode not in", values, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeBetween(String value1, String value2) {
            addCriterion("globalcode between", value1, value2, "globalcode");
            return (Criteria) this;
        }

        public Criteria andGlobalcodeNotBetween(String value1, String value2) {
            addCriterion("globalcode not between", value1, value2, "globalcode");
            return (Criteria) this;
        }

        public Criteria andContinentIsNull() {
            addCriterion("continent is null");
            return (Criteria) this;
        }

        public Criteria andContinentIsNotNull() {
            addCriterion("continent is not null");
            return (Criteria) this;
        }

        public Criteria andContinentEqualTo(String value) {
            addCriterion("continent =", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentNotEqualTo(String value) {
            addCriterion("continent <>", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentGreaterThan(String value) {
            addCriterion("continent >", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentGreaterThanOrEqualTo(String value) {
            addCriterion("continent >=", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentLessThan(String value) {
            addCriterion("continent <", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentLessThanOrEqualTo(String value) {
            addCriterion("continent <=", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentLike(String value) {
            addCriterion("continent like", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentNotLike(String value) {
            addCriterion("continent not like", value, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentIn(List<String> values) {
            addCriterion("continent in", values, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentNotIn(List<String> values) {
            addCriterion("continent not in", values, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentBetween(String value1, String value2) {
            addCriterion("continent between", value1, value2, "continent");
            return (Criteria) this;
        }

        public Criteria andContinentNotBetween(String value1, String value2) {
            addCriterion("continent not between", value1, value2, "continent");
            return (Criteria) this;
        }

        public Criteria andTimezonecityIsNull() {
            addCriterion("timezonecity is null");
            return (Criteria) this;
        }

        public Criteria andTimezonecityIsNotNull() {
            addCriterion("timezonecity is not null");
            return (Criteria) this;
        }

        public Criteria andTimezonecityEqualTo(String value) {
            addCriterion("timezonecity =", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityNotEqualTo(String value) {
            addCriterion("timezonecity <>", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityGreaterThan(String value) {
            addCriterion("timezonecity >", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityGreaterThanOrEqualTo(String value) {
            addCriterion("timezonecity >=", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityLessThan(String value) {
            addCriterion("timezonecity <", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityLessThanOrEqualTo(String value) {
            addCriterion("timezonecity <=", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityLike(String value) {
            addCriterion("timezonecity like", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityNotLike(String value) {
            addCriterion("timezonecity not like", value, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityIn(List<String> values) {
            addCriterion("timezonecity in", values, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityNotIn(List<String> values) {
            addCriterion("timezonecity not in", values, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityBetween(String value1, String value2) {
            addCriterion("timezonecity between", value1, value2, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andTimezonecityNotBetween(String value1, String value2) {
            addCriterion("timezonecity not between", value1, value2, "timezonecity");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaIsNull() {
            addCriterion("administrativearea is null");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaIsNotNull() {
            addCriterion("administrativearea is not null");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaEqualTo(String value) {
            addCriterion("administrativearea =", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaNotEqualTo(String value) {
            addCriterion("administrativearea <>", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaGreaterThan(String value) {
            addCriterion("administrativearea >", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaGreaterThanOrEqualTo(String value) {
            addCriterion("administrativearea >=", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaLessThan(String value) {
            addCriterion("administrativearea <", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaLessThanOrEqualTo(String value) {
            addCriterion("administrativearea <=", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaLike(String value) {
            addCriterion("administrativearea like", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaNotLike(String value) {
            addCriterion("administrativearea not like", value, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaIn(List<String> values) {
            addCriterion("administrativearea in", values, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaNotIn(List<String> values) {
            addCriterion("administrativearea not in", values, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaBetween(String value1, String value2) {
            addCriterion("administrativearea between", value1, value2, "administrativearea");
            return (Criteria) this;
        }

        public Criteria andAdministrativeareaNotBetween(String value1, String value2) {
            addCriterion("administrativearea not between", value1, value2, "administrativearea");
            return (Criteria) this;
        }
    }

    public static class Criteria extends GeneratedCriteria {

        protected Criteria() {
            super();
        }
    }

    public static class Criterion {
        private String condition;

        private Object value;

        private Object secondValue;

        private boolean noValue;

        private boolean singleValue;

        private boolean betweenValue;

        private boolean listValue;

        private String typeHandler;

        public String getCondition() {
            return condition;
        }

        public Object getValue() {
            return value;
        }

        public Object getSecondValue() {
            return secondValue;
        }

        public boolean isNoValue() {
            return noValue;
        }

        public boolean isSingleValue() {
            return singleValue;
        }

        public boolean isBetweenValue() {
            return betweenValue;
        }

        public boolean isListValue() {
            return listValue;
        }

        public String getTypeHandler() {
            return typeHandler;
        }

        protected Criterion(String condition) {
            super();
            this.condition = condition;
            this.typeHandler = null;
            this.noValue = true;
        }

        protected Criterion(String condition, Object value, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.typeHandler = typeHandler;
            if (value instanceof List<?>) {
                this.listValue = true;
            } else {
                this.singleValue = true;
            }
        }

        protected Criterion(String condition, Object value) {
            this(condition, value, null);
        }

        protected Criterion(String condition, Object value, Object secondValue, String typeHandler) {
            super();
            this.condition = condition;
            this.value = value;
            this.secondValue = secondValue;
            this.typeHandler = typeHandler;
            this.betweenValue = true;
        }

        protected Criterion(String condition, Object value, Object secondValue) {
            this(condition, value, secondValue, null);
        }
    }
}