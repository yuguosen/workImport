package com.test.all.importdata.dao.po;

public class Ip {
    private Long id;

    private String source;

    private String ipstart;

    private Long ipstartdigital;

    private String ipend;

    private Long ipenddigital;

    private String area;

    private String areaId;

    private String city;

    private String cityId;

    private String country;

    private String countryId;

    private String county;

    private String countyId;

    private String isp;

    private String ispId;

    private String province;

    private String provinceId;

    private String longitude;

    private String latitude;

    private String addressType;

    private String type;

    private Integer state;

    private String ipowner;

    private String iptimezone;

    private String globalcode;

    private String continent;

    private String timezonecity;

    private String administrativearea;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source == null ? null : source.trim();
    }

    public String getIpstart() {
        return ipstart;
    }

    public void setIpstart(String ipstart) {
        this.ipstart = ipstart == null ? null : ipstart.trim();
    }

    public Long getIpstartdigital() {
        return ipstartdigital;
    }

    public void setIpstartdigital(Long ipstartdigital) {
        this.ipstartdigital = ipstartdigital;
    }

    public String getIpend() {
        return ipend;
    }

    public void setIpend(String ipend) {
        this.ipend = ipend == null ? null : ipend.trim();
    }

    public Long getIpenddigital() {
        return ipenddigital;
    }

    public void setIpenddigital(Long ipenddigital) {
        this.ipenddigital = ipenddigital;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area == null ? null : area.trim();
    }

    public String getAreaId() {
        return areaId;
    }

    public void setAreaId(String areaId) {
        this.areaId = areaId == null ? null : areaId.trim();
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city == null ? null : city.trim();
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId == null ? null : cityId.trim();
    }

    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country == null ? null : country.trim();
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId == null ? null : countryId.trim();
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county == null ? null : county.trim();
    }

    public String getCountyId() {
        return countyId;
    }

    public void setCountyId(String countyId) {
        this.countyId = countyId == null ? null : countyId.trim();
    }

    public String getIsp() {
        return isp;
    }

    public void setIsp(String isp) {
        this.isp = isp == null ? null : isp.trim();
    }

    public String getIspId() {
        return ispId;
    }

    public void setIspId(String ispId) {
        this.ispId = ispId == null ? null : ispId.trim();
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province == null ? null : province.trim();
    }

    public String getProvinceId() {
        return provinceId;
    }

    public void setProvinceId(String provinceId) {
        this.provinceId = provinceId == null ? null : provinceId.trim();
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude == null ? null : longitude.trim();
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude == null ? null : latitude.trim();
    }

    public String getAddressType() {
        return addressType;
    }

    public void setAddressType(String addressType) {
        this.addressType = addressType == null ? null : addressType.trim();
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type == null ? null : type.trim();
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getIpowner() {
        return ipowner;
    }

    public void setIpowner(String ipowner) {
        this.ipowner = ipowner == null ? null : ipowner.trim();
    }

    public String getIptimezone() {
        return iptimezone;
    }

    public void setIptimezone(String iptimezone) {
        this.iptimezone = iptimezone == null ? null : iptimezone.trim();
    }

    public String getGlobalcode() {
        return globalcode;
    }

    public void setGlobalcode(String globalcode) {
        this.globalcode = globalcode == null ? null : globalcode.trim();
    }

    public String getContinent() {
        return continent;
    }

    public void setContinent(String continent) {
        this.continent = continent == null ? null : continent.trim();
    }

    public String getTimezonecity() {
        return timezonecity;
    }

    public void setTimezonecity(String timezonecity) {
        this.timezonecity = timezonecity == null ? null : timezonecity.trim();
    }

    public String getAdministrativearea() {
        return administrativearea;
    }

    public void setAdministrativearea(String administrativearea) {
        this.administrativearea = administrativearea == null ? null : administrativearea.trim();
    }
}